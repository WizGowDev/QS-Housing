--░██████╗░░█████╗░██████╗░░█████╗░░██████╗░███████╗
--██╔════╝░██╔══██╗██╔══██╗██╔══██╗██╔════╝░██╔════╝
--██║░░██╗░███████║██████╔╝███████║██║░░██╗░█████╗░░
--██║░░╚██╗██╔══██║██╔══██╗██╔══██║██║░░╚██╗██╔══╝░░
--╚██████╔╝██║░░██║██║░░██║██║░░██║╚██████╔╝███████╗
--░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝░╚═════╝░╚══════╝

--- @param Option 'qs-garages' https://www.quasar-store.com/package/5142660
--- @param Option 'okokGarage' https://okok.tebex.io/package/5387472
--- @param Option 'cd_garage'  https://codesign.pro/package/4206352
--- @param Option 'jg-advancedgarages' https://store.jgscripts.com/category/advanced-garages
--- @param Option 'qb-garages' https://github.com/qbcore-framework/qb-garages

Config.GarageSystem = 'qs-garages'

Config.MarkerGarage = { --Modify the marker as you like.
    enableMarker = false, 
    enableText = false, 
    type = 2, 
    scale = {x = 0.2, y = 0.2, z = 0.1}, 
    colour = {r = 71, g = 181, b = 255, a = 120},
    movement = 1 --Use 0 to disable movement.
}

-- If you are using a config differnt to qs-garages you can edit this code to make it compatible with your custom garage
function StoreVehicle(house)
    if Config.GarageSystem == 'cd_garage' then -- Save vehicle
        TriggerEvent('cd_garage:StoreVehicle_Main', 1, false)
    elseif Config.GarageSystem == 'okokGarage' then 
        TriggerEvent("okokGarage:StoreVehiclePrivate")
    elseif Config.GarageSystem == 'jg-advancedgarages' then 
        TriggerEvent('jg-advancedgarages:client:InsertVehicle', house, true)
    elseif Config.GarageSystem == 'other' then 
        -- Add your own code here.
    end
end

function OpenGarage(house) -- Open spawn vehicle menu
    if Config.GarageSystem == 'cd_garage' then 
        TriggerEvent('cd_garage:PropertyGarage', 'quick', nil)
    elseif Config.GarageSystem == 'okokGarage' then 
        TriggerEvent("okokGarage:OpenPrivateGarageMenu", GetEntityCoords(PlayerPedId()), GetEntityHeading(PlayerPedId()))
    elseif Config.GarageSystem == 'jg-advancedgarages' then 
        TriggerEvent('jg-advancedgarages:client:ShowHouseGarage:qs-housing', house)
    elseif Config.GarageSystem == 'other' then 
        -- Add your own code here.
    end
end