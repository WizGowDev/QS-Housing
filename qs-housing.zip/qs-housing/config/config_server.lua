
--░██████╗░█████╗░░█████╗░██╗███████╗████████╗██╗░░░██╗
--██╔════╝██╔══██╗██╔══██╗██║██╔════╝╚══██╔══╝╚██╗░██╔╝
--╚█████╗░██║░░██║██║░░╚═╝██║█████╗░░░░░██║░░░░╚████╔╝░
--░╚═══██╗██║░░██║██║░░██╗██║██╔══╝░░░░░██║░░░░░╚██╔╝░░
--██████╔╝╚█████╔╝╚█████╔╝██║███████╗░░░██║░░░░░░██║░░░
--╚═════╝░░╚════╝░░╚════╝░╚═╝╚══════╝░░░╚═╝░░░░░░╚═╝░░░

RegisterServerEvent("qs-housing:server:SocietyJobPayout")
AddEventHandler("qs-housing:server:SocietyJobPayout", function(price) -- Price has already had percentage changes made to it according to the Config.SocietyJobPayout.PercentageToRecieve config option.
    if Config.SocietyJobPayout.SocietyScript == "qb-management" then
        exports['qb-management']:AddMoney(Config.SocietyJobPayout.SocietyName, price)
    elseif Config.SocietyJobPayout.SocietyScript == "custom" then
        -- Add your custom export/event/callback here.
    end
end)


--░█████╗░░█████╗░███╗░░░███╗███╗░░░███╗░█████╗░███╗░░██╗██████╗░░██████╗
--██╔══██╗██╔══██╗████╗░████║████╗░████║██╔══██╗████╗░██║██╔══██╗██╔════╝
--██║░░╚═╝██║░░██║██╔████╔██║██╔████╔██║███████║██╔██╗██║██║░░██║╚█████╗░
--██║░░██╗██║░░██║██║╚██╔╝██║██║╚██╔╝██║██╔══██║██║╚████║██║░░██║░╚═══██╗
--╚█████╔╝╚█████╔╝██║░╚═╝░██║██║░╚═╝░██║██║░░██║██║░╚███║██████╔╝██████╔╝
--░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═════╝░╚═════╝░

RegisterCommand(Config.Commands['addgarage'], function(source, args, rawCommand)
	if Config.Realestatejob[GetJob(source).name] then
		TriggerClientEvent("qs-housing:client:addGarage", source)
	elseif IsPlayerAceAllowed(source, 'addgarages') then -- Or add your own permission check here
		TriggerClientEvent("qs-housing:client:addGarage", source)
	else
		TriggerClientEvent("qs-housing:sendMessage", source, Lang("NO_REALESTATE"), 'inform')
	end
end, false, {help = Config.HelpText['addgarage']})

RegisterCommand(Config.Commands['setpolyzone'], function(source, args, rawCommand)
	if Config.Realestatejob[GetJob(source).name] then
		TriggerClientEvent("qs-housing:client:setPolyZone", source)
	elseif IsPlayerAceAllowed(source, 'setpolyzone') then -- Or add your own permission check here
		TriggerClientEvent("qs-housing:client:setPolyZone", source)
	end
end, false, {help = Config.HelpText['setpolyzone']})

RegisterCommand(Config.Commands['deletehouse'], function(source, args, rawCommand)
	if Config.Realestatejob[GetJob(source).name] and Config.EnableDeleteHousesRealEstate then
		TriggerClientEvent("qs-housing:client:deletehouse", source)
	elseif IsPlayerAceAllowed(source, 'deletehoouse') then -- Or add your own permission check here
		TriggerClientEvent("qs-housing:client:deletehouse", source)
	end
end, false, {help = Config.HelpText['deletehouse']})

--[[ ESX.RegisterCommand('addchargespot', 'user', function (xPlayer, args)
	TriggerClientEvent("qs-housing:client:setLocation", xPlayer.source, {id = "setCharge"})
end, false, {help = "Crear cargador"}) ]]

--[[ RegisterCommand(Config.Commands['createhouse'], function(source, args, rawCommand)
	if args and args[1] then 
		local price = tonumber(args[1])
		if price then
			local isMlo = args[2] == 'yes' and true or false
			if Config.Realestatejob[GetJob(source).name] then
				TriggerClientEvent("qs-housing:client:createHouses", source, price, isMlo)
			elseif IsPlayerAceAllowed(source, 'createhouses') then -- Or add your own permission check here
				TriggerClientEvent("qs-housing:client:createHouses", source, price, isMlo)
			else
				TriggerClientEvent("qs-housing:sendMessage", source, Lang("NO_REALESTATE"), 'inform')
			end
		end
	end
end, false, {help = Config.HelpText['createhouse']}) ]]

--[[ ESX.RegisterCommand('createiplhouse', 'user', function (xPlayer, args)
	local price = tonumber(args.price)
	if true then --
		TriggerClientEvent("qs-housing:client:createHouses", xPlayer.source, price, false, true)
	else
		xPlayer.showNotification("No eres Agente inmobiliario.")
	end
end, false, {help = "Crea una casa.", validate = true, arguments = {
    {name = 'price', help = 'Price', type = 'number'},
}}) ]]


--░██████╗███████╗██████╗░██╗░░░██╗███████╗██████╗░
--██╔════╝██╔════╝██╔══██╗██║░░░██║██╔════╝██╔══██╗
--╚█████╗░█████╗░░██████╔╝╚██╗░██╔╝█████╗░░██████╔╝
--░╚═══██╗██╔══╝░░██╔══██╗░╚████╔╝░██╔══╝░░██╔══██╗
--██████╔╝███████╗██║░░██║░░╚██╔╝░░███████╗██║░░██║
--╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝

RegisterServerEvent('qs-housing:server:addNewHouse')
AddEventHandler('qs-housing:server:addNewHouse', function(street, coords, price, tier, isMlo, iplData)
	local src = source
	local xPlayer = GetPlayerFromIdFramework(src)
	local street = street:gsub("%'", "")
	local price = tonumber(price)
	local tier = tonumber(tier)
	local houseCount = GetHouseStreetCount(street)
	local name = street:lower() .. tostring(houseCount) .. ' #'.. tostring(math.random(1000,9999))
	local label = street .. " " .. tostring(houseCount)
	local isMlo = isMlo
	if not isMlo then 
		isMlo = nil
	end
	MySQL.Async.execute("INSERT INTO houselocations (name, label, coords, owned, price, tier, creator, mlo, ipl) VALUES (@name, @label, @coords, @owned, @price, @tier, @creator, @mlo, @ipl)", {
		['@name'] = name,
		['@label'] = label,
		['@coords'] = json.encode(coords),
		['@owned'] = 0,
		['@price'] = price,
		['@tier'] = tier,
		['@creator'] = xPlayer.identifier,
		['@mlo'] = isMlo,
		['@ipl'] = json.encode(iplData)
	}, function(result)
		if result then
			Config.Houses[name] = {
				coords = coords,
				owned = 0,
				price = price,
				locked = true,
				adress = label, 
				tier = tier,
				garage = {},
				decorations = {},
				mlo = isMlo,
				identifier = nil,
				keys = {},
				ipl = iplData
			}
			UpdateHouseServer(name, Config.Houses[name])
			if isMlo then
				TriggerClientEvent("qs-housing:openMloOptions", src)
			end
		end
	end)
	if Config.WebhookEnable.createhouse then
		sendToDiscordCreateHouse(Config.WebhookTranslates["createhouse"]["title"], 
		Config.WebhookTranslates["createhouse"]["creator"].. " "..GetPlayerName(src).. 
		Config.WebhookTranslates["createhouse"]["price"].. " "..price.. 
		Config.WebhookTranslates["createhouse"]["street"].. " "..label..
		Config.WebhookTranslates["createhouse"]["tier"].. " "..tier..
		Config.WebhookTranslates["createhouse"]["details"].. " "..json.encode(coords), 
		7393279)
	end
end)

RegisterServerEvent('qs-housing:server:detelehouse')
AddEventHandler('qs-housing:server:detelehouse', function(house)
	local src = source
	local house = house
	if house and Config.Houses[house] then 
		if (Config.Realestatejob[GetJob(source).name] and Config.EnableDeleteHousesRealEstate) or IsPlayerAceAllowed(src, 'deletehoouse') then
			MySQL.Async.execute("DELETE FROM houselocations WHERE `name` = @name", {
				['@name'] = house
			}, function(result)
				if result then 
					MySQL.Async.execute("DELETE FROM player_houses WHERE `house` = @house", {
						['@house'] = house
					}, function(result2)
						Config.Houses[house] = nil
						HouseGarages[house] = nil
						UpdateHouseServer(house, Config.Houses[house])
						TriggerClientEvent('qs-housing:sendMessage', src, Lang("HOUSE_DELETED"), 'success')
						TriggerClientEvent('qs-housing:deletehouse', -1, house)
					end)
				end
			end)
			if Config.WebhookEnable.deletehouse then
				sendToDiscordDeleteHouse(Config.WebhookTranslates["deletehouse"]["title"], 
				Config.WebhookTranslates["deletehouse"]["player"].. " "..GetPlayerName(src).. 
				Config.WebhookTranslates["deletehouse"]["house"].. " "..house, 
				7393279)
			end
		end
	end
end)