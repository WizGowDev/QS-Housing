--░█████╗░██╗░░░░░██╗███████╗███╗░░██╗████████╗
--██╔══██╗██║░░░░░██║██╔════╝████╗░██║╚══██╔══╝
--██║░░╚═╝██║░░░░░██║█████╗░░██╔██╗██║░░░██║░░░
--██║░░██╗██║░░░░░██║██╔══╝░░██║╚████║░░░██║░░░
--╚█████╔╝███████╗██║███████╗██║░╚███║░░░██║░░░
--░╚════╝░╚══════╝╚═╝╚══════╝╚═╝░░╚══╝░░░╚═╝░░░

RegisterNetEvent('qs-housing:client:createHouses')
AddEventHandler('qs-housing:client:createHouses', function(price, isMlo, isIpl)
    local pos = PlayerPos
    local heading = GetEntityHeading(PlayerPed)
    local s1, s2 = Citizen.InvokeNative(0x2EB41072B4C1E4C0, pos.x, pos.y, pos.z, Citizen.PointerValueInt(), Citizen.PointerValueInt())
    local street = GetStreetNameFromHashKey(s1):gsub("%-", " ")
    local polyPoints, minZ, maxZ, testCoords = SetupPolyPoints(isMlo)
    if not polyPoints then return end
    if isMlo then
        local coords = {
            enter 	= { x = pos.x, y = pos.y, z = pos.z, h = heading},
            cam 	= { x = pos.x, y = pos.y, z = pos.z, h = heading, yaw = -10.00},
            PolyZone = {
                usePolyZone = true,
                points = polyPoints,
                minZ = minZ,
                maxZ = maxZ
            },
            test = testCoords
        }
        
        TriggerServerEvent('qs-housing:server:addNewHouse', street, coords, price, 1, isMlo)
        return
    end

    if isIpl then
        defaultCoordsPlayer = pos
        local houseName = showCaseOfIplHouse()
        if not houseName then return end
        local configIpl = Config.IplData[houseName]
        local data = configIpl?.export
        local coords = {
            enter 	= { x = pos.x, y = pos.y, z = pos.z, h = heading},
            cam 	= { x = pos.x, y = pos.y, z = pos.z, h = heading, yaw = -10.00},
            PolyZone = {
                usePolyZone = true,
                points = polyPoints,
                minZ = minZ,
                maxZ = maxZ
            }
        }
        if data then
            data = data()
        end
        local iplData = {
            houseName = houseName,
            exit = configIpl.exitCoords,
            theme = data and data.Style.Theme[configIpl.defaultTheme],
            themes = configIpl?.themes
        }
        TriggerServerEvent('qs-housing:server:addNewHouse', street, coords, price, tier, isMlo, iplData)
        return
    end

    local tier, coords = RenderCam()
    if not tier then return end
    local coords = {
        enter 	= { x = pos.x, y = pos.y, z = pos.z, h = heading},
        cam 	= { x = pos.x, y = pos.y, z = pos.z, h = heading, yaw = -10.00},
        PolyZone = {
            usePolyZone = true,
            points = polyPoints,
            minZ = minZ,
            maxZ = maxZ
        },
        interiorCoords = coords
    }
    TriggerServerEvent('qs-housing:server:addNewHouse', street, coords, price, tier, isMlo)
end)

-- Weather inside the house.
RegisterNetEvent("qs-housing:client:WeatherSync")
AddEventHandler("qs-housing:client:WeatherSync", function(bool)
    if bool then
        Wait(150)
        if Config.WeatherSync == 'cd_easytime' then
            TriggerEvent('cd_easytime:PauseSync', true) -- cd_easytime
        elseif Config.WeatherSync == 'qb-weathersync' then
            TriggerEvent('qb-weathersync:client:DisableSync') -- qb-weathersync
        elseif Config.WeatherSync == 'vSync' then
            TriggerEvent('vSync:toggle', false) -- vSync
            Wait(100)
            TriggerEvent('vSync:updateWeather', 'EXTRASUNNY', false) -- vSync
        end
        Wait(50)
        NetworkOverrideClockTime(20, 0, 0) -- 20:00 time inside the house
        ClearOverrideWeather()
        ClearWeatherTypePersist()
        SetWeatherTypePersist("CLEAR")
        SetWeatherTypeNow("CLEAR")
        SetWeatherTypeNowPersist("CLEAR")
        DebugPrint('The time changed to CLEAR because you are indoors.')
    else
        Wait(150)
        if Config.WeatherSync == 'cd_easytime' then
            TriggerEvent('cd_easytime:PauseSync', false) -- cd_easytime
        elseif Config.WeatherSync == 'qb-weathersync' then
            TriggerEvent('qb-weathersync:client:EnableSync') -- qb-weathersync
        elseif Config.WeatherSync == 'vSync' then
            TriggerEvent('vSync:toggle', true) -- vSync
            Wait(100)
            TriggerServerEvent('vSync:requestSync') -- vSync
        end
        DebugPrint('Time resynchronized as he stepped out of the interior.')
    end
end)

-- qb-spawn event.
RegisterNetEvent('qs-housing:client:LastLocationHouse')
AddEventHandler('qs-housing:client:LastLocationHouse', function(houseId)
    if houseId ~= nil then
        closesthouse = houseId
        QSHousing.TriggerServerCallback('qs-housing:server:hasKey', function(result)
            hasKey = result
            if hasKey then 
                ShowStashAndWardrobe = true
            end
            QSHousing.TriggerServerCallback('qs-housing:server:isOwned', function(result)
                isOwned = result
                isOwnedHouseCheck = true
            end, closesthouse)
            while not Config.Houses[closesthouse] do 
                Wait(100) 
            end
            if not Config.Houses[houseId].ipl then
                enterOwnedHouse(houseId)
            else
                enterIplHouse(houseId)
            end
        end, closesthouse)        
    end
end)

-- Create house event
RegisterCommand(Config.Commands['createhouse'], function()
    if PlayerData and PlayerData.job and PlayerData.job.name and Config.Realestatejob[PlayerData.job.name] then
        if not DecoMode then
            OpenHouseMenuRealEstate()
        else 
            Wait(500)
        end
    else 
        SendTextMessage(Lang("NO_REALESTATE"), "error")
    end
end)

-- Command for offset test.
RegisterCommand("offset", function(src, args)
    if args[1] and Config.TestShell[args[1]] then
        TestShell(Config.TestShell[args[1]].obj, args[1])
    else
        SendTextMessage(Lang("OFFSET_NO_EXIST").. " " ..args[1], 'error')
    end
end)

-- Check if the house has a credit or not.
RegisterCommand('checkhouse', function()
    if not closesthouse then 
        return SendTextMessage(Lang("NO_HOUSES_NEARBY"), 'error') 
    end
    QSHousing.TriggerServerCallback('qs-housing:GetCreditState', function(state)
        if state then
            SendTextMessage(Lang("HOUSING_NOTIFICATION_IN_DEBT"), 'inform')
        else
            SendTextMessage(Lang("HOUSING_NOTIFICATION_NO_DEBT"), 'inform')
        end
    end, closesthouse)
end)

-- Event to exit house mode in case the DrawText3D does not appear.
RegisterCommand('leavefix', function()
    if inside then
        SetEntityCoords(PlayerPed, Config.Houses[CurrentHouse].coords.enter.x, Config.Houses[CurrentHouse].coords.enter.y, Config.Houses[CurrentHouse].coords.enter.z, 0, 0, 0, false)
        Wait(500)
        inside = false
        UnloadDecorations()
        TriggerServerEvent('qs-housing:server:SetInsideMetaFalse', house)
        CurrentHouse = nil
    else
        SendTextMessage('You are not inside the home or bugged...', 'inform')
    end
end)

RegisterCommand('decoratefix', function()
    if DecoMode then
        SetNuiFocus(true, true)
    else
        SendTextMessage('You are not in decorate mode...', 'inform')
    end
end)
