
--██╗██████╗░██╗░░░░░  ██╗███╗░░██╗████████╗███████╗██████╗░██╗░█████╗░██████╗░░██████╗
--██║██╔══██╗██║░░░░░  ██║████╗░██║╚══██╔══╝██╔════╝██╔══██╗██║██╔══██╗██╔══██╗██╔════╝
--██║██████╔╝██║░░░░░  ██║██╔██╗██║░░░██║░░░█████╗░░██████╔╝██║██║░░██║██████╔╝╚█████╗░
--██║██╔═══╝░██║░░░░░  ██║██║╚████║░░░██║░░░██╔══╝░░██╔══██╗██║██║░░██║██╔══██╗░╚═══██╗
--██║██║░░░░░███████╗  ██║██║░╚███║░░░██║░░░███████╗██║░░██║██║╚█████╔╝██║░░██║██████╔╝
--╚═╝╚═╝░░░░░╚══════╝  ╚═╝╚═╝░░╚══╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═╝░╚════╝░╚═╝░░╚═╝╚═════╝░

Config.IplData = {
	{ 
    -- Apartment
    export = function () 
        return exports['bob74_ipl']:GetExecApartment1Object() 
    end,
	defaultTheme = 'modern',
    themes = {
			{label = 'Modern', value = 'modern', price = 500},
			{label = 'Moody', value = 'moody', price = 500},
			{label = 'Vibrant', value = 'vibrant', price = 500},
			{label = 'Sharp', value = 'sharp', price = 500},
			{label = 'Monochrome', value = 'monochrome', price = 500},
			{label = 'Seductive', value = 'seductive', price = 500},
			{label = 'Regal', value = 'regal', price = 500},
			{label = 'Aqua', value = 'aqua', price = 500}
		},
        exitCoords = vec3(-787.44, 315.81, 217.64),
		iplCoords = vec3(-787.78050000, 334.92320000, 215.83840000),
	},
  {
    -- Office
		export = function ()
			return exports['bob74_ipl']:GetFinanceOffice1Object()
		end,
		defaultTheme = 'warm',
		themes = {
			{label = 'Warm', value = 'warm', price = 500},
			{label = 'Classical', value = 'classical', price = 500},
			{label = 'Cintage', value = 'vintage', price = 500},
			{label = 'Contrash', value = 'contrast', price = 500},
			{label = 'Rich', value = 'rich', price = 500},
			{label = 'Cool', value = 'cool', price = 500},
			{label = 'Ice', value = 'ice', price = 500},
			{label = 'Conservative', value = 'conservative', price = 500},
			{label = 'Polished', value = 'polished', price = 500}
		},
		exitCoords = vec3(-1579.756, -565.0661, 108.523),
		iplCoords = vec3(-1576.127441, -575.050537, 108.507690),
	},
  {
    -- Night Club
		exitCoords = vec3(-1569.402222, -3017.604492, -74.413940),
		iplCoords = vec3(-1604.664, -3012.583, -78.000),
	},
  {
    -- Clubhouse 1
		exitCoords = vec3(1121.037354, -3152.782471, -37.074707),
		iplCoords = vec3(1107.04, -3157.399, -37.51859),
	},
  {
    -- Clubhouse 2
		exitCoords = vec3(997.028564, -3158.136230, -38.911377),
		iplCoords = vec3(998.4809, -3164.711, -38.90733),
	},
  {
    -- Cocaine Lab
		exitCoords = vec3(1088.703247, -3187.463623, -38.995605),
		iplCoords = vec3(1093.6, -3196.6, -38.99841),
	},
  {
    -- Meth Lab
		exitCoords = vec3(996.896729, -3200.914307, -36.400757),
		iplCoords = vec3(1009.5, -3196.6, -38.99682),
	},
  {
    -- Weed Lab
		exitCoords = vec3(1066.298950, -3183.586914, -39.164062),
		iplCoords = vec3(1056.975830, -3194.571533, -39.164062),
	},
  {
    -- Counterfeit Cash Factory
		exitCoords = vec3(1138.101074, -3199.107666, -39.669556),
		iplCoords = vec3(1121.897, -3195.338, -40.4025),
	},
	{
    -- Document Forgery
		exitCoords = vec3(1173.7, -3196.73, -39.01),
		iplCoords = vec3(1165, -3196.6, -39.01306),
	},
}