
--███████╗██████╗░░█████╗░███╗░░░███╗███████╗░██╗░░░░░░░██╗░█████╗░██████╗░██╗░░██╗
--██╔════╝██╔══██╗██╔══██╗████╗░████║██╔════╝░██║░░██╗░░██║██╔══██╗██╔══██╗██║░██╔╝
--█████╗░░██████╔╝███████║██╔████╔██║█████╗░░░╚██╗████╗██╔╝██║░░██║██████╔╝█████═╝░
--██╔══╝░░██╔══██╗██╔══██║██║╚██╔╝██║██╔══╝░░░░████╔═████║░██║░░██║██╔══██╗██╔═██╗░
--██║░░░░░██║░░██║██║░░██║██║░╚═╝░██║███████╗░░╚██╔╝░╚██╔╝░╚█████╔╝██║░░██║██║░╚██╗
--╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░░░░╚═╝╚══════╝░░░╚═╝░░░╚═╝░░░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝

Config.Framework = 'ESX' -- Set 'ESX' or 'QBCore'.

--- @param If your are using ESX 1.8.5 or higher put in true 'Config.CustomFrameworkExport' and uncomment the ESX function from line 14 
Config.CustomFrameworkExport = true -- Do you want to add your own export?
function CustomFrameworkExport() -- Add the export here, as in the following example.
    ESX = exports["es_extended"]:getSharedObject()
    -- QBCore = exports['qb-core']:GetCoreObject()
end


--█▀▀ █▀▀ █─█ 
--█▀▀ ▀▀█ ▄▀▄ 
--▀▀▀ ▀▀▀ ▀─▀
Config.getSharedObject = 'esx:getSharedObject' -- Modify your ESX-based framework here.
Config.playerLoaded = 'esx:playerLoaded' -- Modify your ESX-based framework here.
Config.setJob = 'esx:setJob' -- Modify your ESX-based framework here.

Config.ESXFrameworkPlayersTable = 'users' -- Name of the table where the data of the players its stored
Config.ESXFrameworkIdentifierTable = 'identifier'  -- Name of the table where the data of the players its stored

Config.ESXMenu = 'esx_menu_default' -- You can choose between 'esx_menu_default', 'nh-context' or 'ox_lib' , if you choose nh-conext you must use nh-keyboard too.

-- Skinchanger and esx_skin events.
Config.skinchangergetSkin = "skinchanger:getSkin"
Config.skinchangerloadClothes = "skinchanger:loadClothes"
Config.esx_skinsetLastSkin = "esx_skin:setLastSkin"
Config.esx_skinsave = "esx_skin:save"

Config.esxVersion = 'new' -- If you are using es_extended 1.2, v1final or legacy use 'new', if you are using es_extended 1.1 use 'old'.

-- In case you are using server custom events from esx_datastore and esx_addoninventory.
Config.esx_addoninventorygetInventory = "esx_addoninventory:getInventory"
Config.esx_datastoregetDataStore = "esx_datastore:getDataStore"
Config.esx_addonaccountgetAccount = "esx_addonaccount:getAccount"

-- Custom event in case you are using esx_inventoryhud (Coming soon)
Config.esx_inventoryhudopenPropertyInventory = "esx_inventoryhud:openPropertyInventory"

-- Multicharacter Event.
Config.MulticharacterEventESX = 'esx:onPlayerLogout'

-- Society events.
Config.societyregisterSociety = 'esx_society:registerSociety'
Config.addonaccountgetSharedAccount = 'esx_addonaccount:getSharedAccount'
Config.societyopenBossMenu = 'esx_society:openBossMenu'



--▒█▀▀█ ▒█▀▀█ ▒█▀▀█ █▀▀█ █▀▀█ █▀▀ 
--▒█░▒█ ▒█▀▀▄ ▒█░░░ █░░█ █▄▄▀ █▀▀ 
--░▀▀█▄ ▒█▄▄█ ▒█▄▄█ ▀▀▀▀ ▀░▀▀ ▀▀▀
Config.QBCoreGetCoreObject = 'qb-core' -- Choose the name of your qb-core export.

-- Clarification, qb-menu should not have its event names changed, use it with events called qb-menu:blablabla.
Config.QBCoreInputName = 'qb-input' -- Choose the name of your qb-input.

Config.QBCoreFrameworkPlayersTable = 'players' -- Name of the table where the data of the players its stored
Config.QBCoreFrameworkIdentifierTable = 'citizenid'  -- Name of the table where the data of the players its stored
Config.QBCoreFrameworkPlayerSkinsTable = 'playerskins' -- Name of the table where the data of the skin players its stored.

Config.QBCoreplayerLoaded = 'QBCore:Client:OnPlayerLoaded' -- Choose the name of your qb-core exports.
Config.QBCoreSetPlayerData = 'QBCore:Player:SetPlayerData' -- Choose the name of your qb-core exports.
Config.QBCoreOpenMenu = 'qb-menu:client:openMenu' -- Choose the name of your qb-core exports.

-- Multicharacter Event
Config.MulticharacterEventQBCore = 'QBCore:Client:OnPlayerUnload' -- Choose the name of your qb-core exports.